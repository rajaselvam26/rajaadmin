<div id="container">
<div class="title-box">
<h2><b>Newsletter History</b></h2>
</div>
<?php echo (isset($_REQUEST['delete_newsletter']))?delete_newsletter(): ''; ?>
<br />
<div id="ajax_view"> </div>
<form method="post" name="pluginform" enctype="multipart/form-data">
<input type="hidden" name="plug_a" id="plug_a" />
<input type="hidden" name="plug_d" id="plug_d" />
<table class="dash_count_table" cellspacing="0">
<tr class="tr_th">
<th width="280">Newsletter</th>
<th width="280">Message</th>
<th width="250">Action</th>
<th width="150">Created date</th>
</tr>
<?php 
$res = pagination(DB_PREFIX."newsletter group by news_id desc",10);
$count = num(DB_PREFIX."newsletter group by news_id");
if($count > 0):
while($page = fetch($res[0])) {
?>
<tr>
<td><?php echo $page->news_id; ?></td>
<td><?php echo limit(strip_tags($page->message),30); ?></td>
<td><a href="?News=Send_Newsletter&Newsletter&edit_newsletter=<?php echo $page->news_id;?>">Edit</a>&nbsp;<a onClick="confirm('Are you want to delete?')?document.location.href='?News=Newsletter_History&Newsletter&delete_newsletter=<?php echo $page->news_id;?>':'';" class="oncl" >Delete</a></td>
<td><?php echo $page->newsletter_date; ?></td>
</tr>
<?php }
 else: ?>
<tr>
<td colspan="5" align="center"><span class="error">No Records !</span></td>
<?php endif; ?>
</tr>
</table>
<?php echo $res[1]; ?>
</form>
</div>