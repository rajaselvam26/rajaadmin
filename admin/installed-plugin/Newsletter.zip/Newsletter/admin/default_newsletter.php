<?php 
$tit='Default Newsletter'; $name='Save_News'; $val='Send Newsletter';
 ?>
<link href="<?php echo current_theme_url();?>style.css" rel="stylesheet" />
<div id="container">
<div class="title-box">
<h2><b><?php echo $tit; ?></b></h2>
</div>
<?php 
echo (isset($_REQUEST['Save_News']))?save_newsletter() : '';
$ftc= fetch_once(DB_PREFIX."newsletter_default","n_d_id!=''");
?>
<br />
<form method="post" enctype="multipart/form-data">
       <fieldset>
       <table>
       <tr> 
       <td>Message</td>
       <td>
       <textarea cols="30" id="editor1" name="message" rows="10"><?=(isset($ftc->message))?$ftc->message:'';?></textarea>
        <script>
            CKEDITOR.replace( 'editor1', {
                fullPage: true,
                allowedContent: true,
                extraPlugins: 'wysiwygarea'
            });
        </script>
       </td>
       </tr>
       <tr> 
       <td colspan="2"><input type="submit" name="<?php echo $name; ?>" class="Button" value="<?php echo $val; ?>" /></td>
       </tr>
       </table>
       </fieldset> 
       </form>       
        </div>