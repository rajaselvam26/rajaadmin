<?php 
require('function.php');
tables();
 ?>
<div id="container">
<div class="title-box">
<h2><b>Newsletter History</b></h2>
</div>
<?php echo (isset($_REQUEST['delete_slider_img']))?delete_slider(): ''; ?>
<br />
<div id="ajax_view"> </div>
<form method="post" name="pluginform" enctype="multipart/form-data">
<input type="hidden" name="plug_a" id="plug_a" />
<input type="hidden" name="plug_d" id="plug_d" />
<table class="dash_count_table" cellspacing="0">
<tr class="tr_th">
<th width="280">Slider</th>
<th width="250">Action</th>
<th width="150">Created date</th>
</tr>
<?php 
$res = pagination(DB_PREFIX."slider order by slider_id desc",10);
$count = num(DB_PREFIX."slider");
if($count > 0):
while($page = fetch($res[0])) {
?>
<tr>
<td><?php echo $page->slider_name; ?></td>
<td><a href="Javascript:Goto('?Nivo_Slider_Admin=add_slider&Nivo Slider&slider_id=<?php echo $page->slider_id;?>');">Edit</a>&nbsp;<a onClick="confirm('Are you want to delete?')?document.location.href='?Nivo_Slider_Admin=myslider&Nivo Slider&delete_slider_img=<?php echo $page->slider_id;?>':'';" class="oncl" >Delete</a></td>
<td><?php echo $page->slider_date; ?></td>
</tr>
<?php }
 else: ?>
<tr>
<td colspan="5" align="center"><span class="error">No Records !</span></td>
<?php endif; ?>
</tr>
</table>
<?php echo $res[1]; ?>
</form>
</div>