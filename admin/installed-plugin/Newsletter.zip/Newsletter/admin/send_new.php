<?php 
$tit='Send Newsletter'; $name='Send_News'; $val='Send Newsletter';
 ?>
<link href="<?php echo current_theme_url();?>style.css" rel="stylesheet" />
<div id="container">
<div class="title-box">
<h2><b><?php echo $tit; ?></b></h2>
</div>
<?php 
echo (isset($_REQUEST['Send_News']))?send_newsletter($_REQUEST) : ''; $emails=array();
if(is_req('edit_newsletter')){ 
$ftc= fetch_once(DB_PREFIX."newsletter","news_id=".$_GET['edit_newsletter']." group by news_id desc");
$sql = select(DB_PREFIX."newsletter where news_id=".$_GET['edit_newsletter']);
while($ftg=fetch($sql)){ $emails[]=$ftg->email;}
}

?>
<br />
<form method="post" enctype="multipart/form-data">
       <fieldset>
       <table>
       <tr> 
       <td>Users</td>
       <td><? $sql= select(DB_PREFIX."users"); ?>
       <select name="email[]" multiple="multiple" style="width:400px; max-height:200px;">
       <? while($ft=fetch($sql)){ ?>
       <option <? if(in_array($ft->email,$emails)){?>selected="selected"<? }?> value="<?=$ft->email?>"><?=$ft->email?></option>
       <? } ?>
       </select></td>
       </tr>
       <tr> 
       <td>Message</td>
       <td>
       <textarea cols="30" id="editor1" name="message" rows="10"><?=(isset($ftc->message))?$ftc->message:'';?></textarea>
        <script>
            CKEDITOR.replace( 'editor1', {
                fullPage: true,
                allowedContent: true,
                extraPlugins: 'wysiwygarea'
            });
        </script>
       </td>
       </tr>
       <tr> 
       <td colspan="2"><input type="submit" name="<?php echo $name; ?>" class="Button" value="<?php echo $val; ?>" /></td>
       </tr>
       </table>
       <input type="hidden" name="news_id" value="<?=rand(1000,10)?>" />
       </fieldset> 
       </form>       
        </div>