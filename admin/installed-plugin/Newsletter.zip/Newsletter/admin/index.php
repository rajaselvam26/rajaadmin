<?php
// File name must be index.php inside of this class
// Class name must be theme_admin => left_menu and page 
class Newsletter{
	public function left_menu(){
		$menu = array(
			'Newsletter' => array('<a href="?News=Newsletter_History&Newsletter">Email History</a>','<a href="?News=Send_Newsletter&Newsletter">Send Email</a>','<a href="?News=Newsletter_Setting&Newsletter">Newsletter Setting</a>')
			);
	return $menu;
	}
	public function page(){	
	        require('function.php');
	        newsletter_tables();	
			$plugin_page = $_REQUEST['News'];
			switch($plugin_page){
				case 'Newsletter_History':
				$plugin_page = include 'history.php';
				break;
				case 'Send_Newsletter':
				$plugin_page = include 'send_new.php';
				break;
				case 'Newsletter_Setting':
				$plugin_page = include 'default_newsletter.php';
				break;
			}
		
		return $plugin_page;
	}	
}
$GLOBALS['plugin_admin'][] = 'Newsletter';
