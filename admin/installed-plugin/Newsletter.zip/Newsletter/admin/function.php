<?php
function current_theme_url(){
	return '../'.THEME_PATH_PREFIX().THEME_BASE().'/'.basename(__DIR__).'/';
}
function newsletter_tables(){
	query("CREATE TABLE IF NOT EXISTS ".DATABASE.".".DB_PREFIX."newsletter (
		`n_id` INT NOT NULL AUTO_INCREMENT ,
		`email` VARCHAR( 255 ) NOT NULL ,
		`news_id` INT NOT NULL ,
		`message` TEXT NOT NULL ,
		`newsletter_date` VARCHAR( 255 ) NOT NULL ,
		`status` VARCHAR( 255 ) NOT NULL ,
		PRIMARY KEY ( `n_id` )
		) ENGINE = InnoDB");
	query("CREATE TABLE IF NOT EXISTS ".DB_PREFIX."newsletter_default (
		`n_d_id` INT NOT NULL AUTO_INCREMENT ,
		`message` TEXT NOT NULL ,
		PRIMARY KEY ( `n_d_id` )
		) ENGINE = InnoDB");
}
function send_newsletter(){ $msg ='';
   echo $_REQUEST['news_id'];
    if(is_req('message','email')){
	$to      = implode(',',$_REQUEST['email']);
	$subject = "Newsletter From doorstepz.com";
	$header = "From: info@doorstepz.com\r\n"; 
	$header.= "MIME-Version: 1.0\r\n"; 
	$header.= "Content-Type: text/html; charset=ISO-8859-1\r\n"; 
	$header.= "X-Priority: 1\r\n"; 
	$message = $_REQUEST['message'];		
	mail($to, $subject, $message, $header);
	foreach($_REQUEST['email'] as $email){
	query("insert into ".DB_PREFIX."newsletter set 
	email = '".$email."',
	message = '".mysql_real_escape_string($_REQUEST['message'])."',
	news_id = '".$_REQUEST['news_id']."',
	newsletter_date = now(),
	status = '1'");
	}
	$msg = success('Newsletter message has been sent successfully!');
	}else{ $msg = error('Please fill required fields!');}
	return $msg;
}
function save_newsletter(){
	if(num(DB_PREFIX."newsletter_default")==1){ $what="update"; }else{ $what="insert into ";}
	query("$what ".DB_PREFIX."newsletter_default set 
	message = '".$_REQUEST['message']."'");
	return success('Newsletter message has been saved!');
}
function delete_newsletter(){$msg='';
		if(isset($_REQUEST['delete_newsletter'])&& ($_REQUEST['delete_newsletter']!='')){ $id = $_REQUEST['delete_newsletter'];
			if(query("delete from ".DB_PREFIX."newsletter where news_id=".$id)){
				$msg = success("Newsletter has been deleted successfully!");
			}			
		}return $msg;
	}