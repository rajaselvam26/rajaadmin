<?php 
require('function.php');

$tit='Add New Slider'; $name='Add_slider'; $val='Add New Slider';
if(isset($_REQUEST['slider_id'])){
	$tit='Update Slider'; $name='Update_slider'; $val='Update Slider';
}
 ?>
<link href="<?php echo current_theme_url();?>style.css" rel="stylesheet" />
<div id="container">
<div class="title-box">
<h2><b><?php echo $tit; ?></b></h2>
</div>
<?php 
echo (isset($_REQUEST['Add_slider']))?add_slider($_REQUEST) : '';
echo (isset($_REQUEST['Update_slider']))? update_slider($_REQUEST,$_REQUEST['post_id']) : '';
if(isset($_REQUEST['slider_id']) && $_REQUEST['slider_id']!=""){
	$get = fetch_once(DB_PREFIX.'slider','slider_id='.$_REQUEST['slider_id']);
}
?>
<br />
<form method="post" enctype="multipart/form-data">
       <fieldset>
       <ul style="float:left;">     
       <p><li>Slider:</li></p>
       <p><li>Upload:</li></p>
       </ul>
       <ul>
       <p><li><input type="text" name="slider_name" value="<?php echo(!empty($_REQUEST['slider_name']))?$_REQUEST['slider_name']:$get->slider_name;?>" /></li></p>
       <p><li><input type="file" name="slider_image" />
       <input type="hidden" name="slider_name_" value="<?php echo $get->slider_image;?>" />
       <?php if(isset($_REQUEST['slider_id'])){?><img src="../images/<?php echo $get->slider_image;?>" width="100" height="100" /><?php } ?>
       </li></p>
       <p><li><input type="submit" name="<?php echo $name; ?>" class="Button" value="<?php echo $val; ?>" /></li></p>
       </ul>
       </fieldset> 
       </form>       
        </div>