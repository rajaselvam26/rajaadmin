<?php include('function.php'); 
if(is_req('Go')){
	if(is_req('newsletteremail')){send_mewsletter();}else{$_SESSION['5_sec_msg']=error('Please enter your email');};
}
?>
<div><b>Newsletter:</b><form method="post"><input type="text" name="newsletteremail" placeholder="Enter your email" />
<input type="hidden" name="Go" value="Go" />
</form></div>