<?php
if(!function_exists('send_newsletter')){
	function send_mewsletter(){
	$to      = $_REQUEST['newsletteremail'];
	$subject = "Newsletter From doorstepz.com";
	$header = "From: info@doorstepz.com\r\n"; 
	$header.= "MIME-Version: 1.0\r\n"; 
	$header.= "Content-Type: text/html; charset=ISO-8859-1\r\n"; 
	$header.= "X-Priority: 1\r\n"; 
	$ft=fetch_once(DB_PREFIX."newsletter_default","n_d_id!=''");
	$message = $ft->message;		
	mail($to, $subject, $message, $header);
	$_SESSION['5_sec_msg']=success('Newsletter message has been sent!');
	}
}