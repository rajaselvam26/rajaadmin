<?php
function func(){
	echo "welcome to function!";
}