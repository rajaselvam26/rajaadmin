<h1>Blue theme is running</h1>
<?php
connect_module('shipping');