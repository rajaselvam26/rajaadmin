<h2><?php echo $title; ?></h2>
<p><?php echo $content; ?></p>
<p><?php echo $date; ?></p>
